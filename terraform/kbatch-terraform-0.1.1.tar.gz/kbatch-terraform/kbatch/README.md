# Install Batch on GKE using Terraform

This folder shows an example of Terraform code that deploys a [Batch on GKE](https://cloud.google.com/batch/) cluster on
[Google Kubernetes Engine](https://cloud.google.com/kubernetes-engine).

## Deploy "Batch on GKE" for the first time in a project

To deploy Batch on GKE:

1. Open `kbatch.tfvars` and fill in all the variables.
1. Run `terraform init`
1. Run `terraform plan -var-file=kbatch.tfvars`
1. If the plan looks good, run `terraform apply -var-file=kbatch.tfvars`

## Deploy "Batch on GKE" in a project that has one or more GKE clusters with "Batch on GKE" installed
Check out the `/modules/gke_cluster/README.md` and `/modules/kbatch/README.md`for instructions.


## Upgrade Batch

1. Open `kbatch.tfvars` and modify the `kbatch_version` field.
1. Run `terraform plan -var-file=kbatch.tfvars`. 3 resources: `module.kbatch_components.kubernetes_deployment.admission`, `module.kbatch_components.kubernetes_secret.admission` and
`module.kbatch_components.kubernetes_stateful_set.controller` should be updated.
1. If the plan looks good, run `terraform apply -var-file=kbatch.tfvars`

## Destroy Batch and delete the GKE cluster

Run `terraform destroy -var-file=kbatch.tfvars`

## How do I create another Kbatch cluster in the same project?
1. Modify `kbatch.tfvars`.
1. Run `terraform state rm 'module.kbatch_components'`
1. Run `terraform plan -var-file=kbatch.tfvars`. Terraform can only manage one cluster resource at one time.
So that if you change the `cluster_name` value, terraform will destroy the existing cluster and create a new one in the same project.
If you don't want to lose the existing cluster, run `terraform state rm 'module.gke_cluster'`.
But removing the cluster state will lose the terraform control of that cluster.
1. If the plan looks good, run `terraform apply -var-file=kbatch.tfvars`

## How do I create another Kbatch cluster in a different project?
1. Modify `kbatch.tfvars`.
1. Run `terraform state rm 'module.kbatch_components'`
1. Run `terraform plan -var-file=kbatch.tfvars`. Terraform will destroy all the existing
resources and create them in the new project.
1. If the plan looks good, run `terraform apply -var-file=kbatch.tfvars`

