# Batch on GKE terraform installation

This repo contains a Terraform Module for how to deploy [Batch on GKE](https://cloud.google.com/batch/) cluster on
[Google Kubernetes Engine](https://cloud.google.com/kubernetes-engine) using [Terraform](https://www.terraform.io/).
Batch on GKE is a cloud-native solution for managing your batch workloads using Kubernetes.


## Prepare the dev environment.

* [Install Google Cloud SDK](https://cloud.google.com/sdk/downloads) and explicitly install kubectl with `apt-get kubectl`.

* [Install Terraform.](https://learn.hashicorp.com/terraform/getting-started/install.html)

* [Create a Project.](https://cloud.google.com/resource-manager/docs/creating-managing-projects) Terraform cannot
help us set up this, so we will have to do this part manually using the Google Cloud console.
The reason is that Terraform needs to work within the context of a project.

* [Enable the GKE API.](https://elastisys.com/2019/04/12/kubernetes-on-gke-from-scratch-using-terraform/)

## Quickstart

If you want to quickly spin up a Kbatch Cluster, you can run the example that is in the `/kbatch` folder of this
repo. Check out the `/kbatch/README.md` for instructions.

## What's in this repo

This repo has the following folder structure:

* `kbatch`: This folder contains an example of how to deploy "Batch on GKE" for the first time in a project.

* `modules`: This folder contains the main implementation code for this Module,
broken down into multiple standalone submodules.

    * `google_could_project`: Project module can be used to configure Google service account and IAM policy bindings.

    * `gke-cluster`: The GKE Cluster module can be used to create a regional [Google Kubernetes Engine (GKE) Cluster](https://cloud.google.com/kubernetes-engine/docs/how-to/cluster-admin-overview) with Workload Identity enabled.

    * `kbatch`: Kbatch module can be used to configure the components for use with a kbatch cluster, including kubernetes
    service accounts, config map, CRDs, kbatch admission service and kbatch controller service.

    * `monitoring`: Monitoring module can be used to create the kbatch-prometheus-service, enable users to view their kbatch metrics from stackdriver monitoring.
