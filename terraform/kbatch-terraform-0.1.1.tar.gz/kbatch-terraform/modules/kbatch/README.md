# Kbatch Module

The Kbatch module can be used to create the following resources:
1. K8s servie account and K8s clusterrolebindings: `kbatch-controllers-k8s-sa`
1. Kbatch custom resources: `batchbudgets`,`batchcostmodels`,`batchjobs` ...
1. K8s config map: `kbatch-config` and `kbatch-machine-types`
1. kbatch admission deployment
1. kbatch controller service and stateful set
1. node termination handler

## Deploy "Batch on GKE" for the first time in a GKE cluster 

1. Open `kbatch.tfvars` and fill in all the variables.
1. Set the kubectl config context: `gcloud config set project $PROJECT_ID && gcloud container clusters get-credentials $CLUSTER_NAME --region=$REGION`
1. Run `terraform init`
1. Run `terraform plan -var-file=kbatch.tfvars`.
1. If the plan looks good, run `terraform apply -var-file=kbatch.tfvars`

## Upgrade Batch

1. Open `kbatch.tfvars` and modify the `kbatch_version` field.
1. Run `terraform plan -var-file=kbatch.tfvars`. 3 resources: `module.kbatch_components.kubernetes_deployment.admission`, `module.kbatch_components.kubernetes_secret.admission` and
`module.kbatch_components.kubernetes_stateful_set.controller` should be updated.
1. If the plan looks good, run `terraform apply -var-file=kbatch.tfvars`

## Deploy "Batch on GKE" in another cluster in a project that already has one or more GKE clusters with "Batch on GKE" installed by Kbatch Module
If you want to destroy all the existing resources and create them in another cluster
1. Run `terraform destroy -var-file=kbatch.tfvars`
1. Modify `kbatch.tfvars`
1. Set the kubectl config context: `gcloud config set project $PROJECT_ID && gcloud container clusters get-credentials $CLUSTER_NAME --region=$REGION`
1. Run `terraform plan -var-file=kbatch.tfvars`
1. If the plan looks good, run `terraform apply -var-file=kbatch.tfvars`

If you want to reserve all the existing resources as well as create the new resources in another cluster:

1. Run
    * `terraform state list`
1. Remove all the existing states, e.g:
    * `terraform state rm 'kubernetes_cluster_role.controller'`
    * `terraform state rm 'kubernetes_cluster_role.node-termination'`
    * `...`
1. Modify `kbatch.tfvars`
1. Set the kubectl config context: `gcloud config set project $PROJECT_ID && gcloud container clusters get-credentials $CLUSTER_NAME --region=$REGION`
1. Run `terraform plan -var-file=kbatch.tfvars`
1. If the plan looks good, run `terraform apply -var-file=kbatch.tfvars`



