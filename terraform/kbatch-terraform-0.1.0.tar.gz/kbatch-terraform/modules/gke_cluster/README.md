# GKE cluster Module

The GKE Cluster module can be used to create  a regional [Google Kubernetes Engine (GKE) Cluster](https://cloud.google.com/kubernetes-engine/docs/how-to/cluster-admin-overview) with Workload Identity enabled.

## Creating the first GKE cluster in a project

1. Open `cluster.tfvars` and fill in all the variables.
1. Run `terraform init`
1. Run `terraform plan -var-file=cluster.tfvars`
1. If the plan looks good, run `terraform apply -var-file=cluster.tfvars`

## Creating GKE clusters in a project that already has one or more GKE clusters created by Terraform
1. Modify `cluster.tfvars`.
1. Run `terraform plan -var-file=cluster.tfvars`. Terraform will destroy the existing
cluster and create a new one.
1. If the plan looks good, run `terraform apply -var-file=cluster.tfvars`
