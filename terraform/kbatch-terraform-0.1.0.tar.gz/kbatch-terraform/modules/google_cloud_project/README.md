# Project Module

The project module can be used to create the following resources:
1. Google servie account: `kbatch-controllers-gcloud-sa@[PROJECT_ID].iam.gserviceaccount.com`
1. Google project IAM binding: `roles/compute.admin`, `roles/iam.serviceAccountUser` and `roles/container.clusterAdmin`
1. Google Service Account IAM binding: `roles/iam.workloadIdentityUser`

## Creating the first kbatch service account in a project
1. Run `terraform init`
1. Run `terraform plan`, fill in the project ID.
1. If the plan looks good, run `terraform apply`, fill in the project ID.

## Creating the kbatch service account in another project
1. Run `terraform apply`, fill in the new project ID.
If the project ID is different from the previous one, terraform will destroy the existing
resources and create them in the new project.

## Creating the kbatch service account in another project, while still keep the existing resources
1. Run:
    * `terraform state rm 'google_project_iam_binding.cluster-admin'`
    * `terraform state rm 'google_project_iam_binding.compute-admin'`
    * `terraform state rm 'google_project_iam_binding.sa-user'`
    * `terraform state rm 'google_service_account.sa'`
    * `terraform state rm 'google_service_account_iam_binding.admin-account-iam'`
1. Run `terraform apply`, fill in the new project ID.
